﻿using System.ComponentModel.DataAnnotations;

namespace MovieTicketBookingSystem.Model
{
    public class Admin
    {
        [Key]
        public int AdminId { get; set; }
        public string AdminName { get; set; }

        [Required]
        public string AdminEmail { get; set; }

        [Required]
        public string Password { get; set; }
    }
}
