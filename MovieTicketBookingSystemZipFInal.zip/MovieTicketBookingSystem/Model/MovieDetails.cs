﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace MovieTicketBookingSystem.Model
{
    public class MovieDetails
    {
        [Key]
        public int MovieId { get; set; }

        [Required]
        public string MovieName { get; set; }

        [Required]
        public string Language { get; set; }

        [Required]
        public string Genre { get; set; }

        [Required]
        public DateTime StartTime { get; set; }

        [Required] 
        public DateTime EndTime { get; set; }

        [Required]
        public int TicketPrice {  get; set; }

        //[ForeignKey("MovieId")]
        //public virtual ICollection<BookingDetail> Booking_Detail { get; set; }

        //public SeatDetail seats { get; set; }
    }
}
