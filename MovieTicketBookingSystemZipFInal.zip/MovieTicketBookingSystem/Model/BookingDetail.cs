﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace MovieTicketBookingSystem.Model
{
    public class BookingDetail
    {
        [Key]
        public int BookingId { get; set; }

        public DateTime StartTime { get; set; }=default(DateTime);


        [Required]
        public double TotalCost { get; set; }=default(double);

        public string SeatNumbers { get; set; }

        public DateTime BookingDate {  get; set; }

       // [ForeignKey("SeatDetails")]
        public int ScreenId { get; set; }

       // public SeatDetail seatDetail { get; set; }

      //  [ForeignKey("User")]
        public int UserId { get; set; }

      // [ForeignKey("Movie")]
        public int MovieId { get; set; }

        //public User User { get; set; }
        //public MovieDetails Movie { get; set; }

    }
}
