﻿namespace MovieTicketBookingSystem.Model
{
    public class Login
    {
        public string Email { get; set; }
        public string Password { get; set; }

        public bool loginAsAdmin { get; set; }
    }
}
