﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace MovieTicketBookingSystem.Model
{
    public class SeatDetail
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int ScreenId { get; set; }

        //[ForeignKey("MovieDetails")]
        public int MovieId {  get; set; }

        //public MovieDetails MovieDetails { get; set; }

        [Required]
        public string ReservedSeats { get; set; }

        [Required]
        public string UnReservedSeats { get; set; }
    }
}
