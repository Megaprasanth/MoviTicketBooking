﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace MovieTicketBookingSystem.Migrations
{
    /// <inheritdoc />
    public partial class createAdminTable : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_BookingDetails_MovieDetails_MovieId",
                table: "BookingDetails");

            migrationBuilder.DropForeignKey(
                name: "FK_BookingDetails_SeatDetail_seatDetailScreenId",
                table: "BookingDetails");

            migrationBuilder.DropForeignKey(
                name: "FK_BookingDetails_Users_UserId",
                table: "BookingDetails");

            migrationBuilder.DropForeignKey(
                name: "FK_SeatDetail_MovieDetails_MovieId",
                table: "SeatDetail");

            migrationBuilder.DropIndex(
                name: "IX_SeatDetail_MovieId",
                table: "SeatDetail");

            migrationBuilder.DropIndex(
                name: "IX_BookingDetails_MovieId",
                table: "BookingDetails");

            migrationBuilder.DropIndex(
                name: "IX_BookingDetails_seatDetailScreenId",
                table: "BookingDetails");

            migrationBuilder.DropIndex(
                name: "IX_BookingDetails_UserId",
                table: "BookingDetails");

            migrationBuilder.DropColumn(
                name: "seatDetailScreenId",
                table: "BookingDetails");

            migrationBuilder.CreateTable(
                name: "Admins",
                columns: table => new
                {
                    AdminId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    AdminName = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    AdminEmail = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Password = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Admins", x => x.AdminId);
                });

            migrationBuilder.InsertData(
                table: "Admins",
                columns: new[] { "AdminId", "AdminEmail", "AdminName", "Password" },
                values: new object[] { 1, "admin@gmail.com", "Admin", "Admin123" });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Admins");

            migrationBuilder.AddColumn<int>(
                name: "seatDetailScreenId",
                table: "BookingDetails",
                type: "int",
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_SeatDetail_MovieId",
                table: "SeatDetail",
                column: "MovieId",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_BookingDetails_MovieId",
                table: "BookingDetails",
                column: "MovieId");

            migrationBuilder.CreateIndex(
                name: "IX_BookingDetails_seatDetailScreenId",
                table: "BookingDetails",
                column: "seatDetailScreenId");

            migrationBuilder.CreateIndex(
                name: "IX_BookingDetails_UserId",
                table: "BookingDetails",
                column: "UserId");

            migrationBuilder.AddForeignKey(
                name: "FK_BookingDetails_MovieDetails_MovieId",
                table: "BookingDetails",
                column: "MovieId",
                principalTable: "MovieDetails",
                principalColumn: "MovieId",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_BookingDetails_SeatDetail_seatDetailScreenId",
                table: "BookingDetails",
                column: "seatDetailScreenId",
                principalTable: "SeatDetail",
                principalColumn: "ScreenId");

            migrationBuilder.AddForeignKey(
                name: "FK_BookingDetails_Users_UserId",
                table: "BookingDetails",
                column: "UserId",
                principalTable: "Users",
                principalColumn: "UserId",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_SeatDetail_MovieDetails_MovieId",
                table: "SeatDetail",
                column: "MovieId",
                principalTable: "MovieDetails",
                principalColumn: "MovieId",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
