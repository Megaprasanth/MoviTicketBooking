﻿namespace MovieTicketBookingSystem.Exceptions
{
    public class BookingDetailNotFoundException : ApplicationException
    {
        public BookingDetailNotFoundException() { }
        public BookingDetailNotFoundException(string message) : base(message) { }
    }
}
