﻿namespace MovieTicketBookingSystem.Exceptions
{
    public class NoSeatAvailableException : ApplicationException
    {
        public NoSeatAvailableException() { }

        public NoSeatAvailableException(string message) : base(message) { }
    }
}
