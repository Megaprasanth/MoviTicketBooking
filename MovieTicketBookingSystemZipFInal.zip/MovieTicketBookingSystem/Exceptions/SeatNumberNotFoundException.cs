﻿namespace MovieTicketBookingSystem.Exceptions
{
    public class SeatNumberNotFoundException : ApplicationException
    {
        public SeatNumberNotFoundException() { }
        public SeatNumberNotFoundException(string message) : base(message) { }
    }
}
