﻿namespace MovieTicketBookingSystem.Exception
{

    public class MovieDetailNotFoundException : ApplicationException
    {
        public MovieDetailNotFoundException() { }
        public MovieDetailNotFoundException(string message) : base(message) { }
    }
}
