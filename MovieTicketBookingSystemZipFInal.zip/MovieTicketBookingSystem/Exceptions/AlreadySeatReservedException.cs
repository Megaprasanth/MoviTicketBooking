﻿namespace MovieTicketBookingSystem.Exceptions
{
    public class AlreadySeatReservedException : ApplicationException
    {
        public AlreadySeatReservedException() { }
        public AlreadySeatReservedException(string message) : base(message) { }
    }
}
