﻿namespace MovieTicketBookingSystem.Exceptions
{
    public class SeatDetailAlreadyExistsException : ApplicationException
    {
        public SeatDetailAlreadyExistsException() { }
        public SeatDetailAlreadyExistsException(string message) : base(message) { }
    }
}
