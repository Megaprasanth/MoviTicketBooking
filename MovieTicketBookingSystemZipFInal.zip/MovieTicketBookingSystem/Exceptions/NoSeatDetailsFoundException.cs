﻿namespace MovieTicketBookingSystem.Exceptions
{
    public class NoSeatDetailsFoundException : ApplicationException
    {
        public NoSeatDetailsFoundException() { }    
        public NoSeatDetailsFoundException(string message) : base(message) { }
    }
}
