﻿namespace MovieTicketBookingSystem.Exception
{
    public class PasswordMismatchException:ApplicationException
    {
        public PasswordMismatchException() { }
        public PasswordMismatchException(string message) : base(message) { }
    }
}
