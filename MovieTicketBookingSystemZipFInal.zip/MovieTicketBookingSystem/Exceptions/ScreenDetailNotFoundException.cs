﻿namespace MovieTicketBookingSystem.Exceptions
{
    public class ScreenDetailNotFoundException : ApplicationException
    {
        public ScreenDetailNotFoundException() { }
        public ScreenDetailNotFoundException(string message) : base(message) { }
    }
}