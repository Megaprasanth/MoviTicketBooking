﻿namespace MovieTicketBookingSystem.Exception
{
    public class MovieDetailAlreadyExistsException : ApplicationException
    {
        public MovieDetailAlreadyExistsException() { }
        public MovieDetailAlreadyExistsException(string message): base(message) { }
    }
}
