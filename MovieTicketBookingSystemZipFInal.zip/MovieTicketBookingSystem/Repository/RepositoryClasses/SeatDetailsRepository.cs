﻿using MovieTicketBookingSystem.Data;
using MovieTicketBookingSystem.Model;
using Microsoft.EntityFrameworkCore;
using MovieTicketBookingSystem.Repository.RepositoryInterfaces;

namespace MovieTicketBookingSystem.Repository.RepositoryClass
{
    public class SeatDetailsRepository : ISeatDetailsRepository
    {
        private readonly MovieDbContext _context;

        public SeatDetailsRepository(MovieDbContext context)
        {
            _context = context;
        }
        public async Task<int> CountReservedSeats(int screenId)
        {
            var screen = await _context.SeatDetails.FirstOrDefaultAsync(x => x.ScreenId == screenId);
            return screen.ReservedSeats.Split(",").Length;
        }

        public async Task<int> CountUnreservedSeats(int screenId)
        {
            var screen = await _context.SeatDetails.FirstOrDefaultAsync(x => x.ScreenId == screenId);
            return screen.UnReservedSeats.Split(",").Length;
        }

        public async Task<List<string>> GetReservedSeats(int screenId)
        {
            var screen = await _context.SeatDetails.FirstOrDefaultAsync(x => x.ScreenId == screenId);
            return screen.ReservedSeats.Split(",").ToList();
        }

        public async Task<List<string>> GetUnReservedSeats(int screenId)
        {
            var screen = await _context.SeatDetails.FirstOrDefaultAsync(x => x.ScreenId == screenId);
            return screen.UnReservedSeats.Split(",").ToList();
        }
        public async Task<SeatDetail> GetSeatDetailByScreenId(int screenId)
        {
            foreach (var seatDetail in _context.SeatDetails)
            {
                if (seatDetail.ScreenId == screenId)
                {
                    return seatDetail;
                }
            }
            return null;
        }

        public async Task<bool> AddSeatDetails(SeatDetail seatDetail)
        {
            _context.SeatDetails.Add(seatDetail);
            return await _context.SaveChangesAsync() == 1;
        }

        public async Task<IEnumerable<SeatDetail>> GetSeatDetails()
        {
            return await _context.SeatDetails.ToListAsync();
        }

        public async Task<bool> DeleteSeatDetail(SeatDetail seatDetail)
        {
            _context.SeatDetails.Remove(seatDetail);
            return await _context.SaveChangesAsync() == 1;
        }

        public async Task<bool> UpdateSeatDetails(SeatDetail seatDetail)
        {
            var updatingSeatDetail = await GetSeatDetailByScreenId(seatDetail.ScreenId);
            updatingSeatDetail.ScreenId = seatDetail.ScreenId;
            updatingSeatDetail.MovieId = seatDetail.MovieId;
            updatingSeatDetail.ReservedSeats= seatDetail.ReservedSeats;
            updatingSeatDetail.UnReservedSeats= seatDetail.UnReservedSeats;
            return await _context.SaveChangesAsync() == 1;
        }
    }
}
