﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using MovieTicketBookingSystem.Data;
using MovieTicketBookingSystem.Model;
using MovieTicketBookingSystem.Repository.RepositoryInterfaces;
using System;

namespace MovieTicketBookingDemo.Repository.RepositoryClass
{
    public class MovieDetailsRepository : IMovieDetailsRepository
    {
        private readonly MovieDbContext _context;

        public MovieDetailsRepository(MovieDbContext context)
        {
            _context = context;
        }

        public async Task<bool> DeleteMovieDetail(MovieDetails movieDetails)
        {
            _context.MovieDetails.Remove(movieDetails);
            return await _context.SaveChangesAsync() == 1;
        }

        public async Task<IEnumerable<MovieDetails>> GetAllMovieDetails()
        {
            return await _context.MovieDetails.ToListAsync();
        }

        public async Task<List<MovieDetails>> GetMovieDetailsByDate(DateTime date)
        {
            return await _context.MovieDetails.Where(x => x.StartTime.Date == date.Date).ToListAsync();
        }

        public async Task<List<MovieDetails>> GetMovieDetailsByGenre(string genre)
        {
            return await _context.MovieDetails.Where(x => x.Genre.Equals(genre)).ToListAsync();
        }

        public async Task<List<MovieDetails>> GetMovieDetailsByLanguage(string language)
        {
            return await _context.MovieDetails.Where(x => x.Language.ToLower().Equals(language.ToLower())).ToListAsync();
        }

        public async Task<List<MovieDetails>> GetMovieDetailsByMovieName(string movieName)
        {
            return await _context.MovieDetails.Where(x => x.MovieName.ToLower().Equals(movieName.ToLower())).ToListAsync();
        }

        public async Task<bool> UpdateMovieDetail(MovieDetails movieDetails)
        {
            var updatingMovieDetail = await _context.MovieDetails.FirstOrDefaultAsync(x => x.MovieId == movieDetails.MovieId);
            updatingMovieDetail.MovieName = movieDetails.MovieName;
            updatingMovieDetail.StartTime = movieDetails.StartTime;
            updatingMovieDetail.EndTime = movieDetails.EndTime;
            updatingMovieDetail.Genre = movieDetails.Genre;
            updatingMovieDetail.Language = movieDetails.Language;
            updatingMovieDetail.TicketPrice = movieDetails.TicketPrice;
            return await _context.SaveChangesAsync() == 1;
        }

        public async Task<bool> AddMovieDetail(MovieDetails movieDetails)
        {
            _context.MovieDetails.Add(movieDetails);
            return await _context.SaveChangesAsync() == 1;
        }

        public async Task<MovieDetails> GetMovieDetailsByMovieId(int movieId)
        {
            return await _context.MovieDetails.FirstOrDefaultAsync(x => x.MovieId == movieId);
        }
    }
}
