﻿using MovieTicketBookingSystem.Data;
using Microsoft.EntityFrameworkCore;
using MovieTicketBookingSystem.Model;
using MovieTicketBookingSystem.Repository.RepositoryInterfaces;


namespace MovieTicketBookingSystem.Repository.RepositoryClass
{
    public class BookingDetailsRepository : IBookingDetailsRepository
    {
        private readonly MovieDbContext _context;

        public BookingDetailsRepository(MovieDbContext context)
        {
            _context = context;
        }

        public async Task<bool> AddBooking(BookingDetail bookingDetail)
        {
            bookingDetail.BookingDate = DateTime.Now;
            await _context.AddAsync(bookingDetail);
            return await _context.SaveChangesAsync() == 1;
        }

        public async Task<MovieDetails> GetMovieDetailsByMovieId(int movieId)
        {
            return await _context.MovieDetails.FirstOrDefaultAsync(x => x.MovieId == movieId);
        }
        public int CalculateNumberOfSeats(BookingDetail booking)
        {
            var numberOfSeats = booking.SeatNumbers.Split(",").Length;
            return numberOfSeats;
        }

        public async Task<double> CalculateTotalCost(BookingDetail booking)
        {
            var movie = await _context.MovieDetails.FirstOrDefaultAsync(x => x.MovieId == booking.MovieId);
            var TicketCostPerPerson = movie.TicketPrice;
            return TicketCostPerPerson * CalculateNumberOfSeats(booking);
        }

        public async Task<BookingDetail> GetBookingDetailByBookingId(int bookingId)
        {
            return await _context.BookingDetails.FirstOrDefaultAsync(x => x.BookingId == bookingId);
        }

        public async Task<List<BookingDetail>> GetBookingDetailByScreenID(int ScreenId)
        {
            return await _context.BookingDetails.Where(x => x.ScreenId == ScreenId).ToListAsync();
        }

        public async Task<List<BookingDetail>> GetBookingDetailByUserId(int userId)
        {
            return await _context.BookingDetails.Where(x => x.UserId == userId).ToListAsync();
        }

        public async Task<bool> CancelTicket(BookingDetail booking)
        {
            _context.BookingDetails.Remove(booking);
            return await _context.SaveChangesAsync() == 1;
        }

        public async Task<SeatDetail> GetSeatDetailByScreenId(int ScreenId)
        {
            return await _context.SeatDetails.FirstOrDefaultAsync(x => x.ScreenId == ScreenId);
        }

        public async Task<bool> UpdateSeatDetails(BookingDetail bookingDetail)
        {
            var seatDetail = await _context.SeatDetails.FirstOrDefaultAsync(x => x.ScreenId == bookingDetail.ScreenId);


            string[] reservedSeats = (string.IsNullOrEmpty(seatDetail.ReservedSeats) ?
                                    seatDetail.ReservedSeats : bookingDetail.SeatNumbers + "," + seatDetail.ReservedSeats)
                                    .Split(",");

            string[] unreservedSeats = seatDetail.UnReservedSeats.Split(",");
            unreservedSeats = unreservedSeats.Except(reservedSeats).ToArray();

            Array.Sort(reservedSeats);
            Array.Sort(unreservedSeats);

            seatDetail.ReservedSeats = string.Join(",", reservedSeats);
            seatDetail.UnReservedSeats = string.Join(",", unreservedSeats);

            return await _context.SaveChangesAsync() == 1;
        }

        public async Task<List<BookingDetail>> GetBookingDetailByScreenId(int screenId)
        {
            return await _context.BookingDetails.Where(x => x.ScreenId == screenId).ToListAsync();
        }
    }
}