﻿using MovieTicketBookingSystem.Data;
using Microsoft.EntityFrameworkCore;
using MovieTicketBookingSystem.Model;
using MovieTicketBookingSystem.Repository.RepositoryInterfaces;

namespace MovieTicketBookingSystem.Repository.RepositoryClass
{
    public class UserRepository : IUserRepository
    {
        private readonly MovieDbContext _context;

        public UserRepository(MovieDbContext context)
        {
            _context = context;
        }

        public async Task<IEnumerable<User>> GetUsers()
        {
            return await _context.Users.ToListAsync();
        }

        public async Task<int> AddUser(User user)
        {
            await _context.Users.AddAsync(user);
            return await _context.SaveChangesAsync();
        }

        public async Task<bool> UpdateUser(User user)
        {
            var updatingUser = await _context.Users.FirstOrDefaultAsync(x => x.UserId == user.UserId);
            updatingUser.UserName = user.UserName;
            updatingUser.PhoneNumber = user.PhoneNumber;
            updatingUser.Password = user.Password;
            return await _context.SaveChangesAsync() == 1;
        }

        public async Task<Admin> GetAdminByEmail(string email)
        {
            return await _context.Admins.FirstOrDefaultAsync(x => x.AdminEmail == email);
        }
        public async Task<int> DeleteUser(int userId)
        {
            var user = await _context.Users.FirstOrDefaultAsync(p => p.UserId == userId);
            _context.Users.Remove(user);
            return await _context.SaveChangesAsync();
        }

        public async Task<User> GetUserByEmail(string email)
        {
            return await _context.Users.FirstOrDefaultAsync(u => u.Email == email);
        }

        public async Task<User> GetUserByUserId(int userId)
        {
            return await _context.Users.FindAsync(userId);
        }

        public async Task<int> GetUserIdByEmail(string email)
        {
            var user = await _context.Users.FirstOrDefaultAsync(u => u.Email == email);
            if (user == null)
            {
                return 0;
            }
            return user.UserId;
        }
    }
}