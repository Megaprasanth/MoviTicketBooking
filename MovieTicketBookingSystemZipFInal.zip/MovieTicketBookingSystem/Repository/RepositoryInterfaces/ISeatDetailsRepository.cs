﻿using MovieTicketBookingSystem.Model;

namespace MovieTicketBookingSystem.Repository.RepositoryInterfaces
{
    public interface ISeatDetailsRepository
    {
        Task<bool> UpdateSeatDetails(SeatDetail seatDetail);
        Task<IEnumerable<SeatDetail>> GetSeatDetails();
        Task<bool> DeleteSeatDetail(SeatDetail seatDetail);
        Task<bool> AddSeatDetails(SeatDetail seatDetail);
        Task<SeatDetail> GetSeatDetailByScreenId(int screenId);
        Task<int> CountReservedSeats(int screenId);
        Task<int> CountUnreservedSeats(int screenId);
        Task<List<string>> GetReservedSeats(int screenId);
        Task<List<string>> GetUnReservedSeats(int screenId);
    }
}
