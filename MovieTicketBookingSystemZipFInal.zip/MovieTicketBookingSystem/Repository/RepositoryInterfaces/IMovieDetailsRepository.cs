﻿using MovieTicketBookingSystem.Model;

namespace MovieTicketBookingSystem.Repository.RepositoryInterfaces
{
    public interface IMovieDetailsRepository
    {
       Task<MovieDetails> GetMovieDetailsByMovieId(int movieId);
        Task<bool> AddMovieDetail(MovieDetails movieDetail);
        Task<List<MovieDetails>> GetMovieDetailsByMovieName(string movieName);
        Task<List<MovieDetails>> GetMovieDetailsByLanguage(string language);
        Task<List<MovieDetails>> GetMovieDetailsByGenre(string genre);
        Task<IEnumerable<MovieDetails>> GetAllMovieDetails();
        Task<bool> DeleteMovieDetail(MovieDetails movieDetails);
        Task<bool> UpdateMovieDetail(MovieDetails movieDetails);
        Task<List<MovieDetails>> GetMovieDetailsByDate(DateTime date);
    }
}
