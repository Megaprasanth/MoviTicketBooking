﻿using MovieTicketBookingSystem.Model;

namespace MovieTicketBookingSystem.Repository.RepositoryInterfaces
{
    public interface IBookingDetailsRepository
    {
        Task<MovieDetails> GetMovieDetailsByMovieId(int movieId);
        Task<bool> UpdateSeatDetails(BookingDetail bookingDetail);
        Task<SeatDetail> GetSeatDetailByScreenId(int screenId);
        Task<bool> AddBooking(BookingDetail bookingDetail);
        Task<bool> CancelTicket(BookingDetail booking);
        Task<BookingDetail> GetBookingDetailByBookingId(int bookingId);
        Task<List<BookingDetail>> GetBookingDetailByScreenId(int screenId);
        Task<List<BookingDetail>> GetBookingDetailByUserId(int userId);
        Task<double> CalculateTotalCost(BookingDetail booking);
        int CalculateNumberOfSeats(BookingDetail booking);
    }
}
