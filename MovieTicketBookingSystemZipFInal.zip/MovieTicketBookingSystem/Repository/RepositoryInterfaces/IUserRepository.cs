﻿using MovieTicketBookingSystem.Model;

namespace MovieTicketBookingSystem.Repository.RepositoryInterfaces
{
        public interface IUserRepository
        {
            Task<Admin> GetAdminByEmail(string email);            
            Task<IEnumerable<User>> GetUsers();
            Task<bool> UpdateUser(User user);
            Task<int> AddUser(User user);
            Task<User> GetUserByUserId(int userId);
            Task<User> GetUserByEmail(string email);
            Task<int> DeleteUser(int userId);
            Task<int> GetUserIdByEmail(string email);
        }
}
