﻿using MovieTicketBookingSystem.Model;

namespace MovieTicketBookingSystem.Services.ServiceInterfaces
{
    public interface ISeatDetailsService
    {
        Task<bool> UpdateSeatDetails(SeatDetail seatDetail);
        Task<IEnumerable<SeatDetail>> GetAllSeatDetails();
        Task<bool> AddSeatDetail(SeatDetail seatDetail);
        Task<bool> DeleteSeatDetail(int screenId);
        Task<SeatDetail> GetSeatDetailByScreenId(int screenId);
        Task<int> CountReservedSeats(int screenId);
        Task<int> CountUnreservedSeats(int ScreenId);
        Task<List<string>> GetReservedSeats(int screenId);
        Task<List<string>> GetUnReservedSeats(int screenId);
    }
}