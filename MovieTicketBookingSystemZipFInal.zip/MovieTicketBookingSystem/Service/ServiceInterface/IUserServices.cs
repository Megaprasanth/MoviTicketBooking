﻿using Microsoft.AspNetCore.Mvc;
using MovieTicketBookingSystem.Model;

namespace MovieTicketBookingSystem.Service.ServiceInterface
{
    public interface IUserServices
    {
        Task<IEnumerable<User>> GetUsers();
        Task<bool> UpdateUser(User user);
        Task<bool> AddUser(User user);
        Task<User> GetUserByUserId(int userId);
        Task<User> GetUserByEmail(string email);
        Task<bool> DeleteUser(int userId);
        Task<int> GetUserIdByEmail(string email);
        Task<bool> Register(User user);
        Task<string> Login(string email, string password,bool loginAsAdmin);
    }
}
