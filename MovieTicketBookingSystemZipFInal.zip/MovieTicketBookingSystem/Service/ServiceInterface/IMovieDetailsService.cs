﻿using MovieTicketBookingSystem.Model;
using Microsoft.AspNetCore.Mvc;

namespace MovieTicketBookingSystem.Services.ServiceInterfaces
{
    public interface IMovieDetailsService
    {
        Task<bool> UpdateMovieDetail(MovieDetails movieDetails);
        Task<bool> DeleteMovieDetails(int busId);
        Task<List<MovieDetails>> GetMovieDetailsByDate(DateTime date);
        Task<bool> AddMovieDetails(MovieDetails MovieDetails);
        Task<List<MovieDetails>> GetMovieDetailsLanguage(string language);
        Task<List<MovieDetails>> GetMovieDetailsByGenre(string genre); 
        Task<IEnumerable<MovieDetails>> GetAllMovieDetails();
    }
}