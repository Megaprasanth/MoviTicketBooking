﻿using MovieTicketBookingSystem.Model;

namespace MovieTicketBookingSystem.Services.ServiceInterfaces
{
    public interface IBookingDetailsService
    {
        Task<bool> IsTicketsAvailable(BookingDetail booking);
        Task<bool> AddBooking(BookingDetail bookingDetail);
        Task<bool> CancelTicket(int bookingId);
        Task<BookingDetail> GetBookingDetailByBookingId(int bookingId);
        Task<List<BookingDetail>> GetBookingDetailByScreenId(int screenId);
        Task<List<BookingDetail>> GetBookingDetailByUserId(int userId);
        Task<double> CalculateTotalCost(BookingDetail booking);
    }
}