﻿using MovieTicketBookingSystem.Exceptions;
using MovieTicketBookingSystem.Model;
using MovieTicketBookingSystem.Repository.RepositoryClass;
using MovieTicketBookingSystem.Repository.RepositoryInterfaces;
using MovieTicketBookingSystem.Services.ServiceInterfaces;
using System.Linq.Expressions;

namespace MovieTicketBookingSystem.Service.ServiceClass
{
    public class SeatDetailsService : ISeatDetailsService
    {
        private readonly ISeatDetailsRepository _repository;

        public SeatDetailsService(ISeatDetailsRepository repository)
        {
            this._repository = repository;
        }

        public async Task<int> CountReservedSeats(int screenId)
        {
            return await _repository.CountReservedSeats(screenId);
        }

        public async Task<int> CountUnreservedSeats(int screenId)
        {
            return await _repository.CountUnreservedSeats(screenId);
        }

        public async Task<List<string>> GetReservedSeats(int screenId)
        {
            var listOfSeats = await _repository.GetReservedSeats(screenId);
            if (listOfSeats.Count() == 0)
            {
                throw new NoSeatAvailableException("No seat is available in this screen ");
            }
            return listOfSeats;
        }

        public async Task<List<string>> GetUnReservedSeats(int screenId)
        {
            var listOfSeats = await _repository.GetUnReservedSeats(screenId);
            if (listOfSeats.Count() == 0)
            {
                throw new NoSeatAvailableException("No seat is available in this screen ");
            }
            return listOfSeats;
        }

        public async Task<SeatDetail> GetSeatDetailByScreenId(int screenId)
        {
            return await _repository.GetSeatDetailByScreenId(screenId);
        }

        public async Task<bool> AddSeatDetail(SeatDetail seatDetail)
        {
            SeatDetail screen = await _repository.GetSeatDetailByScreenId(seatDetail.ScreenId);
            if (screen != null)
            {
                throw new SeatDetailAlreadyExistsException("Your trying to enter the seat detail for the screen is already exists!");
            }
            return await _repository.AddSeatDetails(seatDetail);
        }

        public async Task<IEnumerable<SeatDetail>> GetAllSeatDetails()
        {
            var seatDetails = await _repository.GetSeatDetails();
            if (seatDetails.Count() == 0)
            {
                throw new NoSeatDetailsFoundException("No Seat details found!");
            }
            return seatDetails;
        }

        public async Task<bool> DeleteSeatDetail(int screenId)
        {
            var seatDetail = await _repository.GetSeatDetailByScreenId(screenId);
            if (seatDetail == null)
            {
                throw new NoSeatDetailsFoundException("The seat detail you want to delete is unavailable!");
            }
            return await _repository.DeleteSeatDetail(seatDetail);
        }

        public async Task<bool> UpdateSeatDetails(SeatDetail seatDetail)
        {
            var updatingSeatDetail = await _repository.GetSeatDetailByScreenId(seatDetail.ScreenId);
            if(updatingSeatDetail == null)
            {
                throw new NoSeatDetailsFoundException("The seat details with the given screen id is not found!");
            }
            return await _repository.UpdateSeatDetails(seatDetail);
        }
    }
}
