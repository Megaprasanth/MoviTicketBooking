﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using MovieTicketBookingSystem.Exception;
using MovieTicketBookingSystem.Model;
using MovieTicketBookingSystem.Repository;
using MovieTicketBookingSystem.Repository.RepositoryInterfaces;
using MovieTicketBookingSystem.Service.ServiceInterface;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;

namespace MovieTicketBookingSystem.Service.ServiceClass
{
    public class UserService : IUserServices
    {
        private readonly IUserRepository _repository;

        private readonly IConfiguration _Config;

        public UserService(IUserRepository repository,IConfiguration config)
        {
            this._repository = repository;
            _Config = config;
        }
        public async Task<IEnumerable<User>> GetUsers()
        {
            return await _repository.GetUsers();
        }
        public async Task<bool> AddUser(User user)
        {
            var isUserAlreadyExists = await _repository.GetUserByEmail(user.Email);
            if (isUserAlreadyExists != null)
            {
                throw new UserAlreadyExistsException($"User is already exists with this email Id : {user.Email}!");
            }
            var rowsAffected = await _repository.AddUser(user);
            return rowsAffected == 1;
        }

        public async Task<bool> DeleteUser(int userId)
        {
            var isUserExist = await _repository.GetUserByUserId(userId);
            if (isUserExist == null)
            {
                throw new UserNotFoundException("User is not exists with this userId!"); ;
            }
            return await _repository.DeleteUser(userId) == 1;
        }

        public async Task<string> GenerateJWT(string email,string password,string role)
        {
            var securityKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_Config["JWT:Key"]));

            var credentials = new SigningCredentials(securityKey, SecurityAlgorithms.HmacSha256);

            var claims = new[]
            {
                new Claim(ClaimTypes.Email,email),
                new Claim(ClaimTypes.Role,role)
            };

            var token = new JwtSecurityToken
                (
                    issuer : _Config["JWT:Issuer"],
                    audience: _Config["JWT:Audience"],
                    claims:claims,
                    expires:DateTime.Now.AddMinutes(60),
                    signingCredentials:credentials
                );

            var jwt = new JwtSecurityTokenHandler().WriteToken(token);
            return jwt;
        }

        public async Task<string> Login(string email, string password,bool loginAsAdmin)
        {
            string role = loginAsAdmin ? "Admin" : "User" ;
            if (loginAsAdmin)
            {
                var admin = await _repository.GetAdminByEmail(email);
                if (admin == null)
                {
                    throw new UserNotFoundException($"Admin is not exist with this email id : {email}!");
                }
                if (!admin.Password.Equals(password))
                {
                    throw new PasswordMismatchException("Your password wrong.Try again..!");
                }
            }
            else
            {
                var user = await _repository.GetUserByEmail(email);
                if (user == null)
                {
                    throw new UserNotFoundException($"User is not exist with this email id : {email}!");
                }
                if (!user.Password.Equals(password))
                {
                    throw new PasswordMismatchException("Your password wrong.Try again..!");
                }
            }
            return await GenerateJWT(email,password,role);
        }
        public async Task<User> GetUserByEmail(string email)
        {
            return await _repository.GetUserByEmail(email);
        }

        public async Task<User> GetUserByUserId(int userId)
        {
            var user = await _repository.GetUserByUserId(userId);
            if (user == null)
            {
                throw new UserNotFoundException("User is not exists with this userId!");
            }
            return user;
        }

        public async Task<int> GetUserIdByEmail(string email)
        {
            var userId = await _repository.GetUserIdByEmail(email);
            if (userId == 0)
            {
                throw new UserNotFoundException($"User is not exists with this email id {email}!");
            }
            return userId;
        }


        public async Task<bool> Register(User user)
        {
            var isUserAlreadyExists = await _repository.GetUserByEmail(user.Email);
            if (isUserAlreadyExists == null)
            {
                int rowsAffected = await _repository.AddUser(user);
                return true;
            }
            else
            {
                throw new UserAlreadyExistsException($"User is already eexists with this email : {user.Email}");
            }
        }

        public async Task<bool> UpdateUser(User user)
        {
            var updatingUser = await _repository.GetUserByUserId(user.UserId);
            if (updatingUser == null)
            {
                throw new UserNotFoundException($"User is not exists with this email id {user.Email}!");
            }
            return await _repository.UpdateUser(user);
        }

    }
}