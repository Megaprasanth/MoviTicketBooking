﻿using MovieTicketBookingSystem.Exception;
using MovieTicketBookingSystem.Model;
using MovieTicketBookingSystem.Repository.RepositoryInterfaces;
using MovieTicketBookingSystem.Services.ServiceInterfaces;

namespace MovieTicketBookingSystem.Service.ServiceClass
{
    public class MovieDetailsService : IMovieDetailsService
    {
        private readonly IMovieDetailsRepository _repository;
        public MovieDetailsService(IMovieDetailsRepository repository) 
        {
            _repository = repository;
        }
        public async Task<bool> AddMovieDetails(MovieDetails movieDetails)
        {
            var MovieDetail = await _repository.GetMovieDetailsByMovieName(movieDetails.MovieName);
            if(MovieDetail == null)
            {
                throw new MovieDetailAlreadyExistsException("The movie details youre trying to add is already exists!");
            }
            return await _repository.AddMovieDetail(movieDetails);
        }

        public async Task<bool> DeleteMovieDetails(int movieId)
        {
            var movieDetail = await _repository.GetMovieDetailsByMovieId(movieId);
            if(movieDetail == null)
            {
                throw new MovieDetailAlreadyExistsException("Movie detail not found");
            }
            return await _repository.DeleteMovieDetail(movieDetail);
        }

        public Task<List<MovieDetails>> GetMovieDetailsByDate(DateTime date)
        {
            return _repository.GetMovieDetailsByDate(date);
        }

        public async Task<List<MovieDetails>> GetMovieDetailsByGenre(string genre)
        {
            return await _repository.GetMovieDetailsByGenre(genre);
        }


        public async Task<List<MovieDetails>> GetMovieDetailsLanguage(string language)
        {
            return await _repository.GetMovieDetailsByLanguage(language); 
        }

        public async Task<bool> UpdateMovieDetail(MovieDetails movieDetails)
        {
           var movieDetail = await _repository.GetMovieDetailsByMovieId(movieDetails.MovieId);
            if(movieDetail == null)
            {
                throw new MovieDetailNotFoundException("Movie Detail is not found!");
            }
            return  await _repository.UpdateMovieDetail(movieDetail);
        }

        public async Task<IEnumerable<MovieDetails>> GetAllMovieDetails()
        {
            return await _repository.GetAllMovieDetails();
        }
    }
}
