﻿using MovieTicketBookingSystem.Exceptions;
using MovieTicketBookingSystem.Model;
using MovieTicketBookingSystem.Repository.RepositoryInterfaces;
using MovieTicketBookingSystem.Services.ServiceInterfaces;

namespace MovieTicketBookingSystem.Service.ServiceClass
{
    public class BookingDetailsService : IBookingDetailsService
    {
        private readonly IBookingDetailsRepository _repository;

        public BookingDetailsService(IBookingDetailsRepository repository)
        {
            this._repository = repository;
        }

        public async Task<bool> AddBooking(BookingDetail bookingDetail)
        {
            var movie = await _repository.GetMovieDetailsByMovieId(bookingDetail.MovieId);
            bookingDetail.StartTime = (movie.StartTime);
            bookingDetail.TotalCost = await _repository.CalculateTotalCost(bookingDetail);
            if (!await IsTicketsAvailable(bookingDetail))
            {
                throw new AlreadySeatReservedException("Selected Seats are not Available");
            }
            await _repository.UpdateSeatDetails(bookingDetail);
            return await _repository.AddBooking(bookingDetail);
        }

        public Task<double> CalculateTotalCost(BookingDetail booking)
        {
            return _repository.CalculateTotalCost(booking);
        }


        public async Task<bool> CancelTicket(int bookingId)
        {
            var booking = await _repository.GetBookingDetailByBookingId(bookingId);
            if (booking == null)
            {
                throw new BookingDetailNotFoundException("Your booking not found.Try again..!");
            }
            return await _repository.CancelTicket(booking);
        }

        public async Task<BookingDetail> GetBookingDetailByBookingId(int bookingId)
        {
            var bookingDetail = await _repository.GetBookingDetailByBookingId(bookingId);
            if (bookingDetail == null)
            {
                throw new BookingDetailNotFoundException("There no booking with this booking id!");
            }
            return bookingDetail;
        }

        public async Task<List<BookingDetail>> GetBookingDetailByScreenId(int screenId)
        {
            return await _repository.GetBookingDetailByScreenId(screenId);
        }

        public async Task<List<BookingDetail>> GetBookingDetailByUserId(int userId)
        {
            var bookings = await _repository.GetBookingDetailByUserId(userId);
            if (bookings == null)
            {
                throw new System.Exception("No previous bookings!");
            }
            return bookings.OrderByDescending(x => x.BookingDate).ToList();
        }

        public async Task<bool> IsTicketsAvailable(BookingDetail booking)
        {
            var seatDetail = await _repository.GetSeatDetailByScreenId(booking.ScreenId);
            string[] unReservedSeats = seatDetail.UnReservedSeats.Split(",");
            string[] AllSeats = (seatDetail.ReservedSeats + "," + seatDetail.UnReservedSeats).Split(",");
            string[] givenSeats = booking.SeatNumbers.Split(",");
            bool isAllTicketsAvailable = givenSeats.All(AllSeats.Contains);
            if (isAllTicketsAvailable)
            {
                return givenSeats.All(unReservedSeats.Contains);
            }
            else
            {
                throw new SeatNumberNotFoundException("You're entered seat number is not found in the given screen");
            }
        }
    }
}
