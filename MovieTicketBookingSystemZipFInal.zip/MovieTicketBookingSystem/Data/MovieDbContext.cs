﻿using Microsoft.EntityFrameworkCore;
using MovieTicketBookingSystem.Model;

namespace MovieTicketBookingSystem.Data
{
    public class MovieDbContext : DbContext
    {
        public MovieDbContext(DbContextOptions<MovieDbContext> options) : base(options)
        { }

        public DbSet<MovieDetails> MovieDetails { get; set; }
        public DbSet<User> Users { get; set; }
        public DbSet<SeatDetail> TimingDetails { get; set; }
        public DbSet<BookingDetail> BookingDetails { get; set; }
        public DbSet<Admin> Admins { get; set; }
        public DbSet<SeatDetail> SeatDetails { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Admin>().HasData(
                new Admin { AdminId=1,AdminName="Admin",AdminEmail = "admin@gmail.com",Password="Admin123"}
                );
            base.OnModelCreating(modelBuilder);
        }

    }
   
}
