﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using MovieTicketBookingSystem.Data;
using MovieTicketBookingSystem.Model;
using MovieTicketBookingSystem.Services.ServiceInterfaces;

namespace MovieTicketBookingSystem.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class MovieDetailsController : ControllerBase
    {
        private readonly IMovieDetailsService _service;

        public MovieDetailsController(IMovieDetailsService service)
        {
            _service = service;
        }

        [HttpGet("GetAllMovieDetails")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> GetAllMovieDetails()
        {
            try
            {
                return Ok(await _service.GetAllMovieDetails());
            }
            catch (System.Exception e)
            {
                return BadRequest(e.Message);
            }
        }

        [HttpPost("AddMovieDetail")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> AddMovieDetail([FromBody]MovieDetails movieDetails)
        {
            try
            {
                return Ok(await _service.AddMovieDetails(movieDetails));
            }
            catch(System.Exception e)
            {
                return BadRequest(e.Message);
            }
        }

        [HttpPut("UpdateMovieDetail")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> UpdateMovieDetail([FromBody]MovieDetails movieDetails)
        {
            try
            {
                return Ok(await _service.UpdateMovieDetail(movieDetails));
            }
            catch(System.Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpDelete("DeleteMovieDetail")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> DeleteMovieDetails([FromQuery]int busId)
        {
            try
            {
                return Ok(await _service.DeleteMovieDetails(busId));
            }
            catch(System.Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpGet("GetMovieDetailsByDate")]
        [AllowAnonymous]
        public async Task<IActionResult> GetMovieDetailsByDate([FromQuery]DateTime date)
        {
            try
            {
                return Ok(await _service.GetMovieDetailsByDate(date));
            }
            catch (System.Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpGet("GetMovieDetailsByLanguage")]
        [AllowAnonymous]
        public async Task<IActionResult> GetMovieDetailsLanguage([FromQuery]string language)
        {
            try
            {
                return Ok(await _service.GetMovieDetailsLanguage(language));
            }
            catch (System.Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpGet("GetMovieDetailsByGenre")]
        [AllowAnonymous]
        public async Task<IActionResult> GetMovieDetailsByGenre(string genre)
        {
            try
            {
                return Ok(await _service.GetMovieDetailsByGenre(genre));
            }
            catch(System.Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
    }
}
