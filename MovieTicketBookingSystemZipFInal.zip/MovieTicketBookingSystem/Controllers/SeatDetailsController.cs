﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using MovieTicketBookingSystem.Model;
using MovieTicketBookingSystem.Services.ServiceInterfaces;

namespace MovieTicketBookingSystem.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class SeatDetailsController : ControllerBase
    {
        private readonly ISeatDetailsService _service;

        public SeatDetailsController(ISeatDetailsService service)
        {
            _service = service;
        }

        [HttpGet]
        [Authorize(Roles ="Admin")]
        public async Task<IActionResult> GetSeatDetails([FromQuery] int screenId)
        {
            try
            {
                var seatDetails = await _service.GetSeatDetailByScreenId(screenId);
                return Ok(seatDetails);
            }
            catch (System.Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPost("AddSeatDetails")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> AddSeatDetails([FromBody] SeatDetail seatDetail)
        {
            try
            {
                await _service.AddSeatDetail(seatDetail);
                return Ok("you're successfully added your seat details!");
            }
            catch (System.Exception e)
            {
                return BadRequest(e.Message);
            }
        }

        [HttpGet("AllSeatDetails")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> GetAllSeatDetails()
        {
            try
            {
                return Ok(await _service.GetAllSeatDetails());
            }
            catch (System.Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpDelete("DeleteSeatDetails")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> DeleteSeatDetail([FromQuery] int screenId)
        {
            try
            {
                await _service.DeleteSeatDetail(screenId);
                return Ok("Seat detail was deleted successfully!");
            }
            catch (System.Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpPut]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> UpdateScreenDetail([FromBody] SeatDetail seatDetail)
        {
            try
            {
                return Ok(await _service.UpdateSeatDetails(seatDetail));
            }
            catch (System.Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
    }
}
