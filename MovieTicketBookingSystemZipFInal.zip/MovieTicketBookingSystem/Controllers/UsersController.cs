﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using MovieTicketBookingSystem.Data;
using MovieTicketBookingSystem.Model;
using Microsoft.VisualStudio.Web.CodeGenerators.Mvc.Templates.BlazorIdentity.Pages;
using MovieTicketBookingSystem.Service.ServiceInterface;
using Microsoft.AspNetCore.Authorization;

namespace BusTicketBookingDemo.Controllers
{
    [Route("/api/[controller]")]
    [ApiController]
    public class UsersController : ControllerBase
    {
        private readonly IUserServices _service;

        public UsersController(IUserServices service)
        {
            _service = service;
        }

        // GET: api/Users
        [HttpGet]
        [Authorize(Roles = "Admin")]
        public async Task<ActionResult<IEnumerable<User>>> GetUsers()
        {
            return Ok(await _service.GetUsers());
        }

        [HttpGet("MyProfile")]
        [Authorize(Roles = "User")]
        public async Task<IActionResult> MyProfile([FromQuery] int userId)
        {
            try
            {
                return Ok(await _service.GetUserByUserId(userId));
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPost("Login")]
        [AllowAnonymous]
        public async Task<IActionResult> Login([FromBody] MovieTicketBookingSystem.Model.Login user)
        {
            try
            {
                    return Ok(await _service.Login(user.Email, user.Password, user.loginAsAdmin));
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPost("Register")]
        [AllowAnonymous]
        public async Task<IActionResult> Register([FromBody] User user)
        {
            try
            {
                await _service.AddUser(user);
                return Ok("User registered successfully!");
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPut("UpdateUserDetails")]
        [Authorize(Roles = "User")]
        public async Task<IActionResult> UpdateUser([FromBody] User user)
        {
            try
            {
                await _service.UpdateUser(user);
                return Ok("User detail is updated successfully!");
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpDelete("DeleteMyAccount/{id}")]
        [Authorize(Roles = "User")]
        public async Task<IActionResult> DeleteMyAccount([FromRoute] int id)
        {
            try
            {
                await _service.DeleteUser(id);
                return Ok("Yor account was deleted successfully!");
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
    }
}
