﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using MovieTicketBookingSystem.Data;
using MovieTicketBookingSystem.Model;
using MovieTicketBookingSystem.Services.ServiceInterfaces;

namespace MovieTicketBookingSystem.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BookingDetailsController : ControllerBase
    {
        private readonly IBookingDetailsService _service;
        public BookingDetailsController(IBookingDetailsService service)
        {
            _service = service;
        }

        [HttpGet("BookingDetail")]
        [Authorize(Roles = "User")]
        public async Task<IActionResult> GetBookingDetailsByBookingId([FromQuery] int bookingId)
        {
            try
            {
                var booking = await _service.GetBookingDetailByBookingId(bookingId);
                return Ok(booking);
            }
            catch (System.Exception e)
            {
                return BadRequest(e.Message);
            }
        }

        [HttpGet("PreviousBookings")]
        [Authorize(Roles = "User")]
        public async Task<IActionResult> GetPreviousBookings([FromQuery] int userId)
        {
            try
            {
                var previousBookings = await _service.GetBookingDetailByUserId(userId);
                return Ok(previousBookings);
            }
            catch (System.Exception e)
            {
                return BadRequest(e.Message);
            }
        }

        [HttpPost("AddBooking")]
        [Authorize(Roles = "User")]
        public async Task<IActionResult> AddBooking([FromBody] BookingDetail booking)
        {
            try
            {
                await _service.AddBooking(booking);
                return Ok("Your ticket is booked successfully!");
            }
            catch (System.Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpDelete("CancelTicket")]
        [Authorize(Roles = "User")]
        public async Task<IActionResult> CancelTicket([FromQuery] int bookingId)
        {
            try
            {
                await _service.CancelTicket(bookingId);
                return Ok("Your ticket was cancelled successfully!");
            }
            catch (System.Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
    }
}
