﻿using Microsoft.AspNetCore.Mvc.Filters;

namespace MovieTicketBookingSystem.Aspects
{
    public class ExceptionHandlerAttribute : ExceptionFilterAttribute
    {
        public void OnException(ExceptionContext context)
        {
            base.OnException(context);
        }
    }
}
